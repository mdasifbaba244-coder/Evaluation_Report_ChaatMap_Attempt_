# ChaatMap – StreetBite Safety Sprint

## Run the project
1. Download and extract `chaatmap-project.zip`.
2. Open `index.html` in Chrome, Edge or Firefox.
3. An internet connection is needed for the Leaflet/OpenStreetMap map. The vendor directory and review demo still work without the map.
4. Reviews are saved in the browser's LocalStorage. Use the same browser on the same device to see them again.

## What is included
- Street vendor directory with search, locality and specialty filters.
- Interactive Leaflet map with vendor markers.
- Vendor details and four-factor hygiene breakdown.
- Weighted 5-star score.
- Community review form; submitting a review updates the vendor's factor averages.
- Optional image preview, sample food trail, sample FSSAI and open/closed labels.
- Responsive red-and-black theme.

## Hygiene formula
Score = (0.40 × Water) + (0.25 × Covered food) + (0.20 × Gloves/headgear) + (0.15 × Surroundings)

Each factor is rated from 1 to 5. The weights add up to 1, so the final score remains on a 5-point scale.

## Important project limitations
This is a beginner-friendly front-end prototype, not a production full-stack system. It uses sample vendor records and browser LocalStorage rather than a shared database/server. Reviews are stored locally on the device. The photo is previewed in the form but is not uploaded or saved. FSSAI labels and opening status are illustrative and are not verified. Replace sample records with researched/consented vendor data before presenting them as real.
